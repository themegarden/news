$(function () {
  "use strict";

  //===menu fix js===
  if ($(".main_menu").offset() != undefined) {
    var navoff = $(".main_menu").offset().top;
    $(window).scroll(function () {
      var scrolling = $(this).scrollTop();

      if (scrolling > navoff) {
        $(".main_menu").addClass("menu_fix");
      } else {
        $(".main_menu").removeClass("menu_fix");
      }
    });
  }

  //===BANNER SLIDER===
  $(".banner_slider").slick({
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    centerMode: true,
    variableWidth: true,
    dots: false,
    arrows: true,
    nextArrow: '<i class="far fa-angle-right nextArrow"></i>',
    prevArrow: '<i class="far fa-angle-left prevArrow"></i>',

    responsive: [
      {
        breakpoint: 1400,
        settings: {
          variableWidth: false,
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 1200,
        settings: {
          centerMode: false,
          variableWidth: false,
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 992,
        settings: {
          centerMode: false,
          variableWidth: false,
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 768,
        settings: {
          centerMode: false,
          variableWidth: false,
          arrows: false,
          slidesToShow: 1,
        },
      },
      {
        breakpoint: 576,
        settings: {
          centerMode: false,
          variableWidth: false,
          arrows: false,
          slidesToShow: 1,
        },
      },
    ],
  });

  //===TRENDY SLIDER===
  $(".trendy_slider").slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    dots: false,
    arrows: true,
    nextArrow: '<i class="far fa-angle-right nextArrow"></i>',
    prevArrow: '<i class="far fa-angle-left prevArrow"></i>',

    responsive: [
      {
        breakpoint: 1400,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  });

  //===LARGE ARTICAL SLIDER===
  $(".large_artical_slider").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    dots: true,
    arrows: false,
  });

  //===magnificPopup.js===
  if ($(".popup-youtube").length > 0) {
    $(".popup-youtube").magnificPopup({
      disableOn: 700,
      type: "iframe",
      mainClass: "mfp-fade",
      removalDelay: 160,
      preloader: false,
      fixedContentPos: false,
    });
  }

  if ($(".zoom").length > 0) {
    $(".zoom").magnificPopup({
      type: "image",
      gallery: {
        enabled: true,
      },
      removalDelay: 300,
      mainClass: "mfp-fade",
    });
  }

  //===TRENDY POST SLIDER===
  $(".trendy_post_slider").slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    dots: false,
    arrows: false,

    responsive: [
      {
        breakpoint: 1400,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  });

  //===GALLERY SLIDER===
  $(".gallery_slider").slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    dots: false,
    arrows: false,

    responsive: [
      {
        breakpoint: 1400,
        settings: {
          slidesToShow: 5,
        },
      },
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  });

  //=====STICKY SIDEBAR======
  $("#sticky_sidebar").stickit({
    top: 90,
  });

  //======wow js=======
  new WOW().init();

  //===BANNER 2 SLIDER===
  $(".banner_2_slider").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    dots: true,
    arrows: false,
  });

  //====ISOTOPE=====
  var $grid = $(".grid").isotope({});

  $(".artical_filter").on("click", "button", function () {
    var filterValue = $(this).attr("data-filter");
    $grid.isotope({
      filter: filterValue,
    });
  });

  //active class
  $(".artical_filter button").on("click", function (event) {
    $(this).siblings(".active").removeClass("active");
    $(this).addClass("active");
    event.preventDefault();
  });

  //======MOBILE MENU BUTTON=======
  $(".navbar-toggler").on("click", function () {
    $(".navbar-toggler").toggleClass("show");
  });

  //======CURRENT DATE=======
  if ($(".header_date span").length > 0) {
    document.querySelector(".header_date span").innerHTML =
      new Date().toDateString();
  }

  //======PRELOADER=======
  if ($("body").hasClass("cf-transition")) {
    $(window).on("load", function () {
      setTimeout(function () {
        HideLoad(); // call out animations.
      }, 0);
    });

    function RevealLoad() {
      var tl_transitIn = gsap.timeline({
        defaults: { duration: 1.5, ease: Expo.easeInOut },
      });
      tl_transitIn.set("#page-transition", { autoAlpha: 1 });
      tl_transitIn.to(
        ".sb-overlay",
        { scaleY: 1, transformOrigin: "center bottom" },
        0
      );
      tl_transitIn.to(".sb-preloader", { autoAlpha: 1 }, 0.4);
    }

    // Transitions Out (when "sb-overlay" slides out)
    // ================
    function HideLoad() {
      var tl_transitOut = gsap.timeline();
      tl_transitOut.to(".sb-preloader", {
        duration: 1.5,
        autoAlpha: 0,
        ease: Expo.easeInOut,
      });
      tl_transitOut.to(
        ".sb-overlay",
        {
          duration: 1.5,
          scaleY: 0,
          transformOrigin: "center top",
          ease: Expo.easeInOut,
        },
        0.3
      );

      // Page other elements appear
      tl_transitOut.set("#page-transition", {
        duration: 1.5,
        autoAlpha: 0,
        ease: Expo.easeInOut,
      });
    }

    // On link click
    // ==============
    $("a")
      .not('[target="_blank"]') // omit from selection
      .not('[href^="#"]') // omit from selection
      .not('[href^="mailto"]') // omit from selection
      .not('[href^="tel"]') // omit from selection
      .not(".lg-trigger") // omit from selection
      .not(".no-transition") // omit from selection
      .not(".popup-youtube") // omit from selection
      .not(".zoom") // omit from selection
      .on("click", function (e) {
        e.preventDefault();
        setTimeout(
          function (url) {
            window.location = url;
          },
          1500,
          this.href
        );

        RevealLoad(); // call in animations.
      });
  }
});
